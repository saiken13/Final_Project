package edu.hield.security.services;

import edu.hield.security.entities.User;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface UserService {

    @PreAuthorize("isAuthenticated()")
    void prepareDashboardModel(Model model);

    @PreAuthorize("isAuthenticated()")
    void prepareProfileModel(Model model);

    @PreAuthorize("isAuthenticated()")
    void prepareSettingsModel(Model model);

    @PreAuthorize("isAuthenticated()")
    void updateUserSettings(User updatedUser, String password, List<Long> addIds, List<Long> removeIds);

    @PreAuthorize("hasRole('ADMIN')")
    List<User> getAllUsers();

    @PreAuthorize("hasRole('MANAGER')")
    List<User> getTeamForCurrentManager();

    String storeProfilePicture(Long userId, MultipartFile file);

    // Note: Usually public registration shouldn't be restricted
    User registerNewUser(User user, List<String> roleNames);

    void updateUser(User savedUser);

    User getCurrentUser();
}
