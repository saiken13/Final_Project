package edu.hield.security.services;

import edu.hield.security.dtos.JwtResponse;
import edu.hield.security.dtos.LoginRequest;
import edu.hield.security.entities.User;
import edu.hield.security.utils.CurrentUserContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.ui.Model;

import java.util.List;

public interface AuthService {
    JwtResponse authenticateAndGenerateToken(User user);

    public Cookie loginAndCreateJwtCookie(User user) throws BadCredentialsException;

    void clearJwtCookie(HttpServletResponse response);

}
