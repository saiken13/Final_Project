package edu.hield.security.utils;

import edu.hield.security.entities.User;
import org.springframework.security.core.Authentication;

public record CurrentUserContext(User user, Authentication auth) {}
