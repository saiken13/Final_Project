package edu.hield.security.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import edu.hield.security.entities.User;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);

    boolean existsByUsername(String username);

    List<User> findByManager(User manager);

    List<User> findByManagerIsNull();

    List<User> findAllByOrderByLastNameAsc();
}
