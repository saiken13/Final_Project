package edu.hield.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
